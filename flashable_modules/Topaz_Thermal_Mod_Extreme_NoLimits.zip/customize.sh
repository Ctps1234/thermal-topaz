# Magisk / KernelSU / APatch module customize script
ui_print "- Installing Topaz Thermal Config Mod..."

# Verify architecture / platform
DEVICE_PRODUCT=$(getprop ro.product.device)
DEVICE_NAME=$(getprop ro.build.product)
CHIPSET=$(getprop ro.board.platform)

ui_print "- Detected Device: $DEVICE_PRODUCT ($CHIPSET)"

if [ "$DEVICE_PRODUCT" != "topaz" ] && [ "$DEVICE_PRODUCT" != "tapas" ] && [ "$CHIPSET" != "bengal" ] && [ "$CHIPSET" != "khaje" ]; then
  ui_print "  [!] Warning: This module is designed for Redmi Note 12 4G (topaz/tapas - SM6225)."
  ui_print "  Proceeding anyway on user confirmation..."
fi

# Set proper permissions for vendor etc files
ui_print "- Setting permissions..."
set_perm_recursive $MODPATH/system/vendor/etc 0 0 0755 0644
set_perm_recursive $MODPATH/system/vendor/bin 0 0 0755 0755 2>/dev/null

# Clean old thermal caches
rm -rf /data/vendor/thermal/config/* 2>/dev/null

ui_print "- Thermal optimization successfully installed!"
ui_print "- Please reboot your device to apply changes."
