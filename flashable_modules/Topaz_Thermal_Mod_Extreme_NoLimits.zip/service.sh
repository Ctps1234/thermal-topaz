#!/system/bin/sh
# Restart mi_thermald or apply sconfig on boot completed

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done

# Ensure permissions
chmod 0664 /sys/class/thermal/thermal_message/sconfig 2>/dev/null
chmod 0666 /sys/class/thermal/thermal_message/temp_state 2>/dev/null

# Reset thermal daemon caches if needed
if [ -d /data/vendor/thermal/config ]; then
  rm -f /data/vendor/thermal/config/* 2>/dev/null
fi
